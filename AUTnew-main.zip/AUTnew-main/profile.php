<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Profile Page</title>		
        <?php include('header.php'); ?>
    </head>
	<body class="loggedin">
		<nav class="navtop">
        <?php include('nav.php');?>
		</nav>
		<div class="content">
			<h2>Profile Page</h2>
			<div>
				<p>Your account details are below:</p>
				<table>
					<tr>
						<td>Username:</td>
						<td>Guest</td>
					</tr>
					<tr>
						<td>Name:</td>
						<td>Guest</td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>