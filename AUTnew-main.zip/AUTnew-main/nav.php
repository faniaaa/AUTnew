<div>
    <h1>AUT-NG</h1>
    <a href="index.php"><i class="fas fa-home"></i>Home</a>
    <a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
    <a href="xss1.php"><i class="fas fa-bug"></i>XSS</a>
</div>