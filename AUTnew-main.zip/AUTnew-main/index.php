<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
        <?php include('header.php'); ?>
    </head>
	<body class="loggedin">
		<nav class="navtop">
			<?php include('nav.php');?>
		</nav>
		<div class="content">
			<h2>Home Page</h2>
			<p>Welcome back, Guest!</p>
		</div>
	</body>
</html>